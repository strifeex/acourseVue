<template>
  <div>
    User {{ id }}
    <router-link :to="`/user/${id - 1 }`">Prev</router-link>
    <br>
    <router-link :to="`/user/${id + 1 }`">Next</router-link>
  </div>
</template>

<script>
export default {
  data () {
    return {
      id: 0
    }
  },
  created () {
    this.reload()
  },
  wacth: {
    $route: 'reload'
  },
  methods: {
    reload () {
      this.id = +this.$route.params.id
    }
  }
}
</script>
